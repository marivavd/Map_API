import pygame
import sys
import requests
import os

pygame.init()
screen = pygame.display.set_mode((600, 450))


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


class Button(pygame.sprite.Sprite):
    image = pygame.transform.scale(load_image('search.png', -1), (100, 100))

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Button.image
        self.rect = self.image.get_rect()
        self.rect.x = 250
        self.rect.y = 300


def begin():
    import pygame
    pygame.init()
    screen = pygame.display.set_mode((600, 450))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 30)
    text = "Введите адрес: "
    input_active = True
    running = True
    all_sprites = pygame.sprite.Group()
    button = Button(all_sprites)
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and input_active:
                if event.key == pygame.K_RETURN:
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                else:
                    text += event.unicode
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x = event.pos[0]
                y = event.pos[1]
                if button.rect.collidepoint(x, y):
                    running = False

            screen.fill(0)
            all_sprites.draw(screen)
            all_sprites.update()
            text_surf = font.render(text, True, (255, 255, 255))
            screen.blit(text_surf, text_surf.get_rect(center=screen.get_rect().center))
            pygame.display.flip()

    pygame.quit()
    return text.split(': ')[1]


def show_map(ll_spn, pt, zn, map_type="map"):
    print(pt)
    if ll_spn:
        map_request = f"http://static-maps.yandex.ru/1.x/?ll={ll_spn}&l={map_type}&spn={zn},{zn}&pt={pt}"
    response = requests.get(map_request)
    if not response:
        print("Ошибка выполнения запроса:")
        print(map_request)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        sys.exit(1)

    # Запишем полученное изображение в файл.
    map_file = "map.png"
    try:
        with open(map_file, "wb") as file:
            file.write(response.content)
    except IOError as ex:
        print("Ошибка записи временного файла:", ex)
        sys.exit(2)
    pygame.init()
    screen = pygame.display.set_mode((600, 450))
    screen.blit(pygame.image.load(map_file), (0, 0))
    pygame.display.flip()


def find_coords(address):
    API_KEY = '40d1649f-0493-4b70-98ba-98533de7710b'
    geocoder_api_server = geocoder_request = f"http://geocode-maps.yandex.ru/1.x/?apikey={API_KEY}" \
                                             f"&geocode={address}&format=json"
    response = requests.get(geocoder_api_server).json()
    toponym = response["response"]["GeoObjectCollection"][
        "featureMember"][0]["GeoObject"]
    toponym_coodrinates = toponym["Point"]["pos"]
    coords = list(map(float, toponym_coodrinates.split(' ')))
    return coords


def main():
    address = begin()
    coords = find_coords(address)
    const = [coords[0], coords[1]]
    print('Чтобы поменять вид карты на схему, нажмите на клавишу английской A')
    print('Чтобы поменять вид карты на спутник, нажмите на клавишу английской S')
    print('Чтобы поменять вид карты на гибрид, нажмите на клавишу английской D')
    running = True
    z = 0.03
    show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z))
    map_type = 'map'
    while running:
        print(const)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_PAGEUP:
                    if z < 0.1:
                        z += 0.01
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_PAGEDOWN:
                    if z - 0.01 > 0:
                        z -= 0.01
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_UP:
                    if coords[1] < 55.87:
                        coords[1] += z / 2
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_DOWN:
                    if coords[1] > 55.75:
                        coords[1] -= z / 2
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_LEFT:
                    if coords[0] > 37.68:
                        coords[0] -= z / 2
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_RIGHT:
                    if coords[0] < 37.8:
                        coords[0] += z / 2
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_a:
                    if map_type != 'map':
                        map_type = 'map'
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_s:
                    if map_type != 'sat':
                        map_type = 'sat'
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)
                elif event.key == pygame.K_d:
                    if map_type != 'sat,skl':
                        map_type = 'sat,skl'
                        pygame.quit()
                        os.remove('map.png')
                        show_map(','.join(list(map(str, coords))), ','.join(list(map(str, const))), str(z), map_type)


if __name__ == "__main__":
    main()
